To use this database with JDBC import the mysql-connector-j-8.3.0.jar file to your referenced libraries in JAVA projects in VS code.
Then set the username and password in conn.java file according to the credentials of your sql Workbench.
Start the project from signupOne.java
